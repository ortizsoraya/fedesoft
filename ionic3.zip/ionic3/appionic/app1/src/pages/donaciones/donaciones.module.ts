import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DonacionesPage } from './donaciones';

@NgModule({
  declarations: [
    DonacionesPage,
  ],
  imports: [
    IonicPageModule.forChild(DonacionesPage),
  ],
})
export class DonacionesPageModule {}
