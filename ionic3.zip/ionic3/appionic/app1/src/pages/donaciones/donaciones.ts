import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, MenuController } from 'ionic-angular';
import { AlertController } from 'ionic-angular';
import { HomePage } from '../home/home';
import { AuthDonacionesProvider } from '../../providers/auth-donaciones/auth-donaciones';


@IonicPage()
@Component({
  selector: 'page-donaciones',
  templateUrl: 'donaciones.html',
})
export class DonacionesPage {

  respouceData : any;
  userDetails: any;
  donacionesData =  { "name":"", 
                      "description":"", 
                      "date_limit":""
                    };

  constructor(public navCtrl: NavController, 
              public navParams: NavParams,
              public menu: MenuController,
              public alertCtl: AlertController,
              public authDonacionesProvider: AuthDonacionesProvider) {

    const data = JSON.parse(localStorage.getItem('user'));

    console.log(data);

    this.userDetails = data.user;
  }
  ionViewWillEnter () {
    this.menu.enable (false);
  }
  
  DonacionesUp(){

    this.authDonacionesProvider.postData(this.donacionesData, "products", this.userDetails.auth_token).then((result) => {
    
      this.respouceData = result;
      console.log(this.respouceData);
      localStorage.setItem('products', JSON.stringify(this.respouceData));
      this.navCtrl.push(HomePage);
    
    }, (err) => {    
      let alert = this.alertCtl.create({
        title: 'Registro',     
        subTitle: 'NO se pudo guardar, por favor intente mas tarde.',      
        buttons: ['Dismiss']     
      });
    
    alert.present();
    
    });
    
    }

  ionViewDidLoad() {
   console.log('ionViewDidLoad DonacionesPage');
  }
}
