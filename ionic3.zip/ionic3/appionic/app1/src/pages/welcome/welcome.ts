import { Component } from '@angular/core';
import { NavController, NavParams, MenuController } from 'ionic-angular';

import { LoginPage } from '../login/login'
import { SignUpPage } from '../sign-up/sign-up'
import { SignUpuserPage } from '../sign-upuser/sign-upuser'

@Component({
  selector: 'page-welcome',
  templateUrl: 'welcome.html',
})
export class WelcomePage {

  constructor(public navCtrl: NavController, 
              public navParams: NavParams, 
              public menu: MenuController) {

    this.menu.enable(false);
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad WelcomePage');
  }

  goLogin(){

    this.navCtrl.push(LoginPage);
    
  }
  goSignUp(){
  
    this.navCtrl.push(SignUpPage);
  
  }
  goSignUpuser(){
  
    this.navCtrl.push(SignUpuserPage);

  }
 

}
