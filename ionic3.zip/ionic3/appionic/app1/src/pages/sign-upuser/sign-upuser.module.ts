import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SignUpuserPage } from './sign-upuser';

@NgModule({
  declarations: [
    SignUpuserPage,
  ],
  imports: [
    IonicPageModule.forChild(SignUpuserPage),
  ],
})
export class SignUpuserPageModule {}
