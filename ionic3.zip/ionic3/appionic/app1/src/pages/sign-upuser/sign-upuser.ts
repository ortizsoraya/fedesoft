import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, MenuController } from 'ionic-angular';
import { AlertController } from 'ionic-angular';
import { HomePage } from '../home/home';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';


@IonicPage()
@Component({
  selector: 'page-sign-upuser',
  templateUrl: 'sign-upuser.html',
})
export class SignUpuserPage {

  respouceData : any;
  userData = {"name":"", "email":"",
              "password":"", 
              "password_confirmation":"", 
              "celular":"", 
              "localidad":"",
              "nit":"NA",
              "contacto":"",
              "adress":"",
              "tipo":"1"
          };

  constructor(public navCtrl: NavController, 
              public navParams: NavParams,
              public menu: MenuController,
              public authServiceProvider: AuthServiceProvider,
              public alertCtl: AlertController) {
  }
  ionViewWillEnter () {
    this.menu.enable (false);
  }

  SignUpuser(){

    this.authServiceProvider.postData(this.userData, "sign_up").then((result) => {
    
      this.respouceData = result;
      console.log(this.respouceData);
      localStorage.setItem('user', JSON.stringify(this.respouceData));
      this.navCtrl.push(HomePage);
    
    }, (err) => {    
      let alert = this.alertCtl.create({
        title: 'Registro',     
        subTitle: 'NO se pudo registrar, por favor intente mas tarde.',      
        buttons: ['OK']     
      });
    
    alert.present();
    
    });
    
    }


  ionViewDidLoad() {
    console.log('ionViewDidLoad SignUpuserPage');
  }

}
