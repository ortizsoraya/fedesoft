import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { PerfilPage } from '../pages/perfil/perfil';
import { ContactenosPage } from '../pages/contactenos/contactenos';
import { DonacionesPage } from '../pages/donaciones/donaciones';
import { NoticiasPage } from '../pages/noticias/noticias';

import { WelcomePage } from '../pages/Welcome/Welcome';
import { SignUpPage } from '../pages/sign-up/sign-up';
import { LoginPage } from '../pages/login/login';
import { AuthServiceProvider } from '../providers/auth-service/auth-service';
import { HttpModule } from '@angular/http';
import { SignUpuserPage } from '../pages/sign-upuser/sign-upuser';
import { ImagesProvider } from '../providers/images/images';
import { ImageInfoPage } from '../pages/image-info/image-info';
import { AuthDonacionesProvider } from '../providers/auth-donaciones/auth-donaciones';

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    PerfilPage,
    ContactenosPage,
    DonacionesPage,
    NoticiasPage,
    WelcomePage,
    SignUpPage,
    LoginPage,
    SignUpuserPage,
    ImageInfoPage

  ],
  imports: [
    BrowserModule,
    HttpModule,
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    PerfilPage,
    ContactenosPage,
    DonacionesPage,
    NoticiasPage,
    WelcomePage,
    SignUpPage,
    LoginPage,
    SignUpuserPage,
    ImageInfoPage
    
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    AuthServiceProvider,
    ImagesProvider,
    AuthDonacionesProvider
  ]
})
export class AppModule {}
